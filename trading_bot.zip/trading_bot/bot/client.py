import os
from pathlib import Path

from dotenv import load_dotenv
from binance.client import Client

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"

print("Loading:", ENV_PATH)

load_dotenv(dotenv_path=ENV_PATH)

print("API KEY   :", os.getenv("BINANCE_API_KEY"))
print("API SECRET:", os.getenv("BINANCE_API_SECRET"))

TESTNET_URL = "https://testnet.binancefuture.com"


class BinanceClient:
    def __init__(self):
        self.client = Client(
            os.getenv("BINANCE_API_KEY"),
            os.getenv("BINANCE_API_SECRET"),
        )

        self.client.FUTURES_URL = TESTNET_URL

    def get_client(self):
        return self.client