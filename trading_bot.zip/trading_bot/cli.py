import typer

from bot.client import BinanceClient
from bot.orders import OrderManager
from bot.validators import (
    validate_side,
    validate_order_type,
    validate_quantity,
)

app = typer.Typer(help="Binance Futures Testnet Trading Bot")


@app.command()
def trade(
    symbol: str = typer.Option(
        ..., "--symbol", "-s", help="Trading symbol (e.g. BTCUSDT)"
    ),
    side: str = typer.Option(
        ..., "--side", help="Order side: BUY or SELL"
    ),
    order_type: str = typer.Option(
        ..., "--order-type", help="Order type: MARKET or LIMIT"
    ),
    quantity: float = typer.Option(
        ..., "--quantity", "-q", help="Order quantity"
    ),
    price: float = typer.Option(
        None, "--price", "-p", help="Price (required for LIMIT orders)"
    ),
):
    """
    Place a BUY/SELL MARKET or LIMIT order on Binance Futures Testnet.
    """

    try:
        # Validate inputs
        side = validate_side(side)
        order_type = validate_order_type(order_type)
        quantity = validate_quantity(quantity)

        if order_type == "LIMIT" and price is None:
            raise typer.BadParameter("Price is required for LIMIT orders.")

        # Create Binance client
        client = BinanceClient().get_client()

        # Create order manager
        manager = OrderManager(client)

        # Print request summary
        print("\n========== ORDER REQUEST ==========")
        print(f"Symbol      : {symbol}")
        print(f"Side        : {side}")
        print(f"Order Type  : {order_type}")
        print(f"Quantity    : {quantity}")

        if order_type == "LIMIT":
            print(f"Price       : {price}")

        print("===================================\n")

        # Place order
        response = manager.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
        )

        # Print response
        print("========== ORDER RESPONSE ==========")
        print(f"Order ID    : {response.get('orderId')}")
        print(f"Status      : {response.get('status')}")
        print(f"ExecutedQty : {response.get('executedQty')}")
        print(f"Avg Price   : {response.get('avgPrice', 'N/A')}")
        print("====================================")

        print("\n✅ Order placed successfully!")

    except Exception as e:
        print("\n❌ Failed to place order")
        print(f"Error: {e}")


if __name__ == "__main__":
    app()